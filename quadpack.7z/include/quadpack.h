#ifndef QUADPACK_H
#define QUADPACK_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/**
 * https://www.gnu.org/software/gsl/doc/html/integration.html
 *
 * The algorithms in QUADPACK use a naming convention based on the following letters:
 *
 * Q - quadrature routine
 *
 * N - non-adaptive integrator
 * A - adaptive integrator
 *
 * G - general integrand (user-defined)
 * W - weight function with integrand
 *
 * S - singularities can be more readily integrated
 * P - points of special difficulty can be supplied
 * I - infinite range of integration
 * O - oscillatory weight function, cos or sin
 * F - Fourier integral
 * C - Cauchy principal value
 */

/**
 * QNG non-adaptive Gauss-Kronrod integration
 * QAG adaptive integration
 * QAGS adaptive integration with singularities
 * QAGP adaptive integration with known singular points
 * QAGI adaptive integration on infinite intervals
 * QAWC adaptive integration for Cauchy principal values
 * QAWS adaptive integration for singular functions
 * QAWO adaptive integration for oscillatory functions
 * QAWF adaptive integration for Fourier integrals
 * CQUAD doubly-adaptive integration
 */

typedef double (*integral_fun)(double);

/**
 * @param f function subprogram defining the integrand function f(x)
 * @param a lower limit of integration
 * @param b upper limit of integration
 * @param epsabs absolute accuracy requested
 * @param epsrel relative accuracy requested
 *               If epsabs <= 0 and epsrel < max(50*rel.mach.acc.,0.5d-28), the routine will end with ier = 6.
 * @param result approximation to the integral i
 *
 * @param abserr estimate of the modulus of the absolute error, which should equal or exceed abs(i-result)
 * @param neval number of integrand evaluations
 * @param ier return code
 *        ier = 0 normal and reliable termination of the routine.
 *          it is assumed that the requested accuracy has been achieved.
 *        ier > 0 abnormal termination of the routine.
 *          it is assumed that the requested accuracy has not been achieved.
 *        error messages
 *        ier = 1 the maximum number of steps has been executed.
 *          the integral is probably too difficult to be calculated by dqng.
 *        ier = 6 the input is invalid, because epsabs <= 0 and epsrel < max(50*rel.mach.acc.,0.5d-28).
 *        result, abserr and neval are set to zero.
 */
void dqng_(integral_fun f,
        /* input */
           double *a, double *b,
           double *epsabs, double *epsrel,
        /* output */
           double *result, double *abserr, int *neval, int *ier);


void dqag_(integral_fun f,
        /* input */
           double *a, double *b,
           double *epsabs, double *epsrel, int *key,
        /* output */
           double *result, double *abserr, int *neval, int *ier,
        /* input */
           int *limit, int *lenw, int *last, int *iwork, double *work);

void dqagse_(integral_fun f,
        /* input */
             double *a, double *b,
             double *epsabs, double *epsrel,
             int *limit, double *result,
        /* output */
             double *abserr, int *neval, int *ier,
             double *alist, double *blist, double *rlist, double *elist,
             int *iord, int *last);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif // QUADPACK_H