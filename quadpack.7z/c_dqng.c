
#include "quadpack.h"
#include <math.h>
#include <stdio.h>

/*
 * integral function
 */

/*
ier = 0
result = 1.270724139833620, abserr = 0.000000000000014
neval = 21
 */
static double f1(double x) {
    return exp(x) / (x * x + 1);
}

/*
ier = 1
result = 1.104535684809390, abserr = 0.399071264594829
neval = 87

integral = 2/Sqrt[3] = 1.154700538380521

 TODO WHY?
 */
static double f2(double x) {
    // printf("x = %f\n", x);
    double y = 2.0 / (2.0 + sin(10.0 * M_PI * x));
    return y;
}

int main() {
    double a = 0;
    double b = 1.0;
    double epsabs = 0;
    double epsrel = 1e-3;
    double result, abserr;
    int neval, ier;

    dqng_(f2, &a, &b, &epsabs, &epsrel, &result, &abserr, &neval, &ier);
    printf("ier = %d\n", ier);
    printf("result = %.15f, abserr = %.15f\n", result, abserr);
    printf("neval = %d\n", neval);

    return 0;
}
